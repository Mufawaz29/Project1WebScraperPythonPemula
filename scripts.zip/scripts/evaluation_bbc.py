import pandas as pd
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import numpy as np

# Load data
file_path = "data/bbc_news_with_category.csv"
df = pd.read_csv(file_path)

# Labeling otomatis (pastikan konsisten dengan modelling)
def label_from_text(text):
    text = str(text).lower()
    if any(kw in text for kw in ["politik", "presiden", "pemilu", "dpr"]):
        return "Politik"
    elif any(kw in text for kw in ["ekonomi", "uang", "bisnis", "investasi"]):
        return "Ekonomi"
    elif any(kw in text for kw in ["olahraga", "sepak bola", "pemain", "timnas"]):
        return "Olahraga"
    elif any(kw in text for kw in ["sains", "science", "lingkungan", "environment", "iklim", "energi", "penelitian"]):
        return "Sains"
    else:
        return "Lainnya"

df["Kategori"] = df["Isi_Berita_Clean"].apply(label_from_text)

# Gabungkan kategori minoritas ke 'Lainnya' agar minimal ada 2 kelas
min_count = 2
kategori_counts = df["Kategori"].value_counts()
minor_kategori = kategori_counts[kategori_counts < min_count].index.tolist()
df["Kategori"] = df["Kategori"].apply(lambda x: "Lainnya" if x in minor_kategori else x)

# Cek distribusi
print("📌 Distribusi kategori untuk evaluasi:")
print(df["Kategori"].value_counts())

# Siapkan data
text_col = "Isi_Berita_Clean"
label_col = "Kategori"
X = df[text_col]
y = df[label_col]

if y.nunique() > 1:
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    tfidf = TfidfVectorizer(max_features=5000, ngram_range=(1,2))
    X_train_tfidf = tfidf.fit_transform(X_train)
    X_test_tfidf = tfidf.transform(X_test)
    model = LogisticRegression(max_iter=200)
    model.fit(X_train_tfidf, y_train)
    y_pred = model.predict(X_test_tfidf)

    # Evaluasi
    print("\nAkurasi:", accuracy_score(y_test, y_pred))
    print("\nClassification Report:\n", classification_report(y_test, y_pred))

    # Confusion Matrix
    cm = confusion_matrix(y_test, y_pred, labels=sorted(y.unique()))
    plt.figure(figsize=(6,5))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=sorted(y.unique()), yticklabels=sorted(y.unique()))
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    plt.title('Confusion Matrix')
    plt.show()
else:
    print("\n❗ Tidak cukup variasi kategori untuk evaluasi.")
