import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score
import numpy as np

# ======================
# 1. Load Data
# ======================
data_path = "data/bbc_news_with_category.csv"  # path sudah diperbaiki

# Baca data
try:
    df = pd.read_csv(data_path)
except FileNotFoundError:
    raise FileNotFoundError(f"File {data_path} tidak ditemukan. Pastikan file sudah ada dan path benar.")

print("📌 Kolom tersedia:", df.columns.tolist())

# ======================
# 2. Labeling Otomatis Berdasarkan Isi Berita
# ======================
def label_from_text(text):
    text = str(text).lower()
    if any(kw in text for kw in ["politik", "presiden", "pemilu", "dpr"]):
        return "Politik"
    elif any(kw in text for kw in ["ekonomi", "uang", "bisnis", "investasi"]):
        return "Ekonomi"
    elif any(kw in text for kw in ["olahraga", "sepak bola", "pemain", "timnas"]):
        return "Olahraga"
    elif any(kw in text for kw in ["sains", "science", "lingkungan", "environment", "iklim", "energi", "penelitian"]):
        return "Sains"
    else:
        return "Lainnya"

df["Kategori"] = df["Isi_Berita_Clean"].apply(label_from_text)

# Gabungkan kategori minoritas ke 'Lainnya' agar minimal ada 2 kelas
min_count = 2
kategori_counts = df["Kategori"].value_counts()
minor_kategori = kategori_counts[kategori_counts < min_count].index.tolist()
df["Kategori"] = df["Kategori"].apply(lambda x: "Lainnya" if x in minor_kategori else x)

# Cek ulang distribusi
print("📌 Distribusi kategori setelah penggabungan minoritas:")
print(df["Kategori"].value_counts())

# ======================
# 3. Siapkan Data Teks & Label
# ======================
text_col = "Isi_Berita_Clean"
label_col = "Kategori"

X = df[text_col]
y = df[label_col]

if y.nunique() > 1:
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # ======================
    # 4. TF-IDF Vectorizer
    # ======================
    tfidf = TfidfVectorizer(max_features=5000, ngram_range=(1,2))
    X_train_tfidf = tfidf.fit_transform(X_train)
    X_test_tfidf = tfidf.transform(X_test)

    # ======================
    # 5. Model Logistic Regression
    # ======================
    model = LogisticRegression(max_iter=200)
    model.fit(X_train_tfidf, y_train)

    # ======================
    # 6. Evaluasi
    # ======================
    y_pred = model.predict(X_test_tfidf)
    print("\n📌 Akurasi:", accuracy_score(y_test, y_pred))
    print("\n📌 Laporan Klasifikasi:\n", classification_report(y_test, y_pred))
else:
    print("\n❗ Tidak cukup variasi kategori untuk modelling.")
