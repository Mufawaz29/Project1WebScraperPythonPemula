# Import kembali Library yang ada di file scrape_bbc.py
import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import os
import string 
import re
from Sastrawi.StopWordRemover.StopWordRemoverFactory import StopWordRemoverFactory
import matplotlib.pyplot as plt
from wordcloud import WordCloud


# Path file input dan output
input_path = "data/bbc_news.csv"
output_path = "data/bbc_news_clean.csv"

# Cek apakah file input ada
if not os.path.exists(input_path):
    print(f"File {input_path} tidak ditemukan.")
    exit(1)

# Load data
print("Membaca data...")
df = pd.read_csv(input_path)

# Tampilkan 5 data teratas
print("Data sebelum dibersihkan:")
print(df.head())

# Pastikan kolom Isi_Berita bertipe string dan isi NaN dengan string kosong
df["Isi_Berita"] = df["Isi_Berita"].fillna("").astype(str)

# Hapus duplikat berdasarkan judul dan link
df = df.drop_duplicates(subset=["Judul", "Link"])

# Hapus baris yang isi beritanya kosong atau tidak ditemukan
df = df[df["Isi_Berita"].str.strip().astype(bool)]
df = df[df["Isi_Berita"] != "Isi berita tidak ditemukan"]
df = df[~df["Isi_Berita"].str.startswith("Error")]  # hapus error scraping

# Bersihkan whitespace berlebih pada isi berita
df["Isi_Berita"] = df["Isi_Berita"].str.replace(r"\s+", " ", regex=True).str.strip()

# inisiasi stopwrds bahsa indonesia 
stop_factory = StopWordRemoverFactory()
stopwords = set (stop_factory.get_stop_words())



def clean_text(text):




# Lowercase
    text = text.lower()
    
    # Hapus angka
    text = re.sub(r"\d+", " ", text)
    
    # Hapus tanda baca
    text = text.translate(str.maketrans("", "", string.punctuation))
    
    # Hapus spasi ganda
    text = re.sub(r"\s+", " ", text).strip()
    
    # Hapus stopwords
    words = [word for word in text.split() if word not in stopwords]
    return " ".join(words)

# Cleaning kolom Judul & Isi_Berita
df["Judul_Clean"] = df["Judul"].apply(clean_text)
df["Isi_Berita_Clean"] = df["Isi_Berita"].apply(clean_text)

# Simpan ke CSV baru
df.to_csv(output_path, index=False, encoding="utf-8")

print(f"✅ Data bersih berhasil disimpan di {output_path}")

# Tampilkan 5 data teratas setelah cleaning
print("Data setelah dibersihkan:")
print(df.head())

