import pandas as pd

# Baca data
file_path = "data/bbc_news_clean_with_length.csv"
df = pd.read_csv(file_path)

# Fungsi untuk ekstrak kategori dari link BBC
def extract_category(url):
    if pd.isna(url):
        return "Unknown"
    parts = url.split("/")
    for p in parts:
        if p in ["news", "sport", "business", "politics", "technology", "entertainment", "science", "indonesia"]:
            return p.capitalize()
    return "Lainnya"

# Tambahkan kolom Kategori
df["Kategori"] = df["Link"].apply(extract_category)

# Simpan kembali
df.to_csv("data/bbc_news_with_category.csv", index=False, encoding="utf-8")

print("5 data teratas dengan kategori:")
print(df.head())
