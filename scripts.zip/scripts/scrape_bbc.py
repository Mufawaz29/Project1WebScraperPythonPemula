import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import os

url = "https://www.bbc.com/indonesia"

response = requests.get(url, timeout=10)
soup = BeautifulSoup(response.text, "html.parser")

# Cari semua link berita artikel
articles = soup.find_all("a", href=True)

berita_links = []
for a in articles:
    href = a['href']
    if "/indonesia/articles/" in href and a.get_text(strip=True):
        link = href if href.startswith("http") else "https://www.bbc.com" + href
        berita_links.append((a.get_text(strip=True), link))

# Hilangkan duplikat
seen = set()
data = []
for title, link in berita_links:
    if link not in seen:
        seen.add(link)
        data.append({"Judul": title, "Link": link})

# Ambil isi berita
for i, row in enumerate(data[:15]):  # ambil 15 dulu
    link = row["Link"]
    print(f"[{i+1}/{len(data)}] Ambil isi: {link}")
    isi_berita = ""
    try:
        res = requests.get(link, timeout=10)
        soup_berita = BeautifulSoup(res.text, "html.parser")

        # 1️⃣ Cara utama
        paragraphs = soup_berita.find_all("div", {"data-component": "text-block"})
        isi_berita = " ".join([p.get_text(strip=True) for p in paragraphs])

        # 2️⃣ Kalau kosong, coba cari <p>
        if not isi_berita:
            ps = soup_berita.find_all("p")
            isi_berita = " ".join([p.get_text(strip=True) for p in ps])

        if not isi_berita:
            isi_berita = "Isi berita tidak ditemukan"

        time.sleep(1)
    except Exception as e:
        isi_berita = f"Error: {e}"

    row["Isi_Berita"] = isi_berita

# Simpan CSV
os.makedirs("data", exist_ok=True)
df = pd.DataFrame(data)
df.to_csv("data/bbc_news.csv", index=False, encoding="utf-8")
print("✅ Berhasil simpan ke data/bbc_news.csv")
