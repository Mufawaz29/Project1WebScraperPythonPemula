import pandas as pd
import matplotlib.pyplot as plt
from wordcloud import WordCloud, STOPWORDS

# 1. Load Data
file_path = "data/bbc_news_with_category.csv"
df = pd.read_csv(file_path)

print("📌 5 data teratas:")
print(df.head())

print("\n📌 Info dataset:")
print(df.info())

# 2. Analisis Panjang Berita
print("\n📌 Distribusi panjang berita (jumlah kata):")
df['Panjang_Berita'] = df['Isi_Berita_Clean'].apply(lambda x: len(str(x).split()))
print(df['Panjang_Berita'].describe())

plt.figure(figsize=(10,6))
df['Panjang_Berita'].hist(bins=30, color="skyblue", edgecolor="black")
plt.title('Distribusi Panjang Berita (Jumlah Kata)', fontsize=14)
plt.xlabel('Jumlah Kata')
plt.ylabel('Frekuensi')
plt.grid(axis='y', alpha=0.5)
plt.show()

# 3. WordCloud
all_text = " ".join(df['Isi_Berita_Clean'].dropna().tolist())
stopwords = set(STOPWORDS)
stopwords.update(["yang", "untuk", "ini", "dengan", "karena", "pada", "akan"])
wordcloud = WordCloud(
    width=1000, height=500, background_color='white',
    stopwords=stopwords, colormap='viridis'
).generate(all_text)

plt.figure(figsize=(12,6))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')
plt.title("☁️ Wordcloud Berita BBC", fontsize=16)
plt.show()

# 4. Simpan hasil tambahan
df.to_csv("data/bbc_news_clean_with_length.csv", index=False, encoding="utf-8")
print("✅ Hasil EDA sudah disimpan di data/bbc_news_clean_with_length.csv")